var stringManipulation = require("./string-manipulation-restructured")();

console.log(stringManipulation.stringToOrdinal("aabb"));
