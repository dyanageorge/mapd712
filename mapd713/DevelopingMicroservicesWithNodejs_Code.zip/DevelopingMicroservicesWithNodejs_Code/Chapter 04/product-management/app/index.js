var plugin = function(options) {
    var seneca = this;
    
    /**
     * Fetch the list of all the products.
     */
    seneca.add({area: "product", action: "fetch"}, function(args, done) {
        var products = this.make("products");
        products.list$({}, done);
    });
    
    /**
     * Fetch the list of products by category.
     */
    seneca.add({area: "product", action: "fetch", criteria: "byCategory"}, function(args, done) {
        var products = this.make("products");
        products.list$({category: args.category}, done);
    });
    
    /**
     * Fetch a product by id.
     */
    seneca.add({area: "product", action: "fetch", criteria: "byId"}, function(args, done) {
        var product = this.make("products");
        //product.load$(args.product_id, done);
       product.list$({}, done);
    });
    
    /**
     * Adds a product.
     */
    seneca.add({area: "product", action: "add"}, function(args, done) {
        var products = this.make("products");
        products.product_id = args.product_id;
        products.category = args.category;
        products.name = args.name;
        products.description = args.description;
        products.category = args.category;
        products.price = args.price
        products.category = args.category;

        products.save$(function(err, product) {
            done(err, products.data$(false));
        });
    });
    

    /**
     * Removes a product by id.
     */
    seneca.add({area: "product", action: "delete-all"}, function(args, done) {
        var product = this.make("products");
        product.remove$(function(err) {
            done(err, null);
        });
    });
    
    /**
     * Removes a product by id.
     */
    seneca.add({area: "product", action: "delete"}, function(args, done) {
        var product = this.make("products");
        product.remove$(args.product_id, function(err) {
            done(err, null);
        });
    });
    
    /**
     * Edits a product fetching it by id first.
     */
    seneca.add({area: "product", action: "edit"}, function(args, done) {
        seneca.act({area: "product", action: "fetch", criteria: "byId", id: args.product_id}, function(err, result) {
            result.data$(
                    {
                        name: args.name, 
                        category: args.category, 
                        description: args.description,
                        price: args.price                        
                      }
            );
            result.save$(function(err, product){
                done(err, product.data$(false));
            });
        });
    });

    ////////////////////////////////////////////////////

    seneca.add('role:api,cmd:zig',function(args,done){
    done(null,{zig:'zig'})
    })
    
    seneca.add('role:api,cmd:bar',function(args,done){
    done(null,{bar:'bar' })
    })
    
    seneca.add('role:api,cmd:qaz',function(args,done){
    console.log("--->>> args.zoo=" + args.zoo + ", args.id="+ args.id+ ", args.product_id="+ args.product_id);
    done(null,{qaz:args.zoo+'z--' + args.id})
    })
    ////////////////////////////////////////////////////



}
module.exports = plugin;



var seneca = require("seneca")();
seneca.use(plugin);
seneca.use('seneca-entity');
seneca.use("mongo-store", {
    name: "seneca",
    host: "127.0.0.1",
    port: "27017"
});

seneca.ready(function(err){
    console.log("db connected");
    seneca.act('role:web',{use:{
      prefix: '/products',
      pin: {area:'product',action:'*'},
      map:{
        fetch: {GET:true},
        add: {GET:false,POST:true},          
        edit: {GET:false,POST:true},
        delete: {GET: false, DELETE: true},
        'delete-all': {GET: true, DELETE: true}        
      }
    }});

    seneca.act('role:web', {use: {
            prefix: '/my-api',
            pin: { role: 'api', cmd: '*' },
            map: {
                zig: true,                // GET is the default
                bar: { GET: true },          // explicitly accepting GETs
                qaz: { GET: true, POST: true } // accepting both GETs and POSTs
            }
        }
    })

    var express = require('express');
    var app = express();

    app.use( require("body-parser").json() )
    
    // This is how you integrate Seneca with Express
    app.use( seneca.export('web') );

    app.listen(3000);
    console.log("Server listening on: //localhost:"+3000);

});
