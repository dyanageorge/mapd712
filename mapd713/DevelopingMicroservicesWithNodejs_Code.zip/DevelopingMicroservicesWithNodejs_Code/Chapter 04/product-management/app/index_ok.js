var plugin = function(options) {
    var seneca = this;
    
    seneca.add({area: "product", action: "fetch"}, function(args, done) {
        console.log("-->fetch");
        var products = this.make("products");
        products.list$({}, done);
    });

    seneca.add({area: "product", action: "fetchbyid"}, function(args, done) {
        console.log("-->fetchbyid, item_id:"+ args.item_id );
        var products = this.make("products");
        products.list$({id:args.item_id}, done);
    });

   seneca.add({area: "product", action: "add"}, function(args, done) {
        console.log("-->add, item_name:"+ args.item_name );
        
        var products = this.make("products");
        products.category = args.category;
        products.item_name = args.item_name;
        products.description = args.description;
        products.category = args.category;
        products.price = args.price

        products.save$(function(err, product) {
            done(err, products.data$(false));
        });
    });

    seneca.add({area: "product", action: "delete"}, function(args, done) {
        console.log("-->delete, item_id:"+ args.item_id );
        var product = this.make("products");
        product.remove$(args.item_id, function(err) {
            done(err, null);
        });
    });


    seneca.add({ area: "product", action: "edit" }, function (args, done) {
        console.log("-->edit, item_id:" + args.item_id);
        var products = this.make("products");
        products.list$({ id: args.item_id }, function (err, result) {
             console.log("-->-->: products.list$ id:" + args.item_id);
                console.log("-->-->: products.data$");
                console.log("-->-->: result[0]: " + result[0].item_name);
                // TODO: if not found, return error
                var product = result[0]; // first element
                product.data$(
                    {
                        name: args.item_name,
                        category: args.category,
                        description: args.description,
                        price: args.price
                    }
                );
                console.log("-->-->: products.save$");                
                product.save$(function (err, result) {
                    console.log("-->-->-->: product.data$, product:"+ product);
                    done(err, result.data$(false));
                });
            }


        );
    });
    
}
module.exports = plugin;



var seneca = require("seneca")();
seneca.use(plugin);
seneca.use('seneca-entity');
seneca.use("mongo-store", {
    name: "seneca",
    host: "127.0.0.1",
    port: "27017"
});

seneca.ready(function(err){
    console.log("db connected");
    seneca.act('role:web',{use:{
      prefix: '/products',
      pin: {area:'product',action:'*'},
      map:{
        fetch: {GET:true},
        fetchbyid: {GET:true, suffix: '/:item_id'},
        add: {GET:false,POST:true},
        delete: {DELETE:true, suffix: '/:item_id'},
        edit: {PUT:true, suffix: '/:item_id'}
      }
    }});

    var express = require('express');
    var app = express();

    app.use( require("body-parser").json() )
    
    // This is how you integrate Seneca with Express
    app.use( seneca.export('web') );

    app.listen(3000);
    console.log("Server listening on: //localhost:"+3000);
    console.log("--- Actions -----------");
    console.log("http://localhost:3000/products/fetch");
    console.log("http://localhost:3000/products/fetchbyid/123");
    console.log("http://localhost:3000/products/add");
    console.log("http://localhost:3000/products/delete");
    console.log("http://localhost:3000/products/edit/123");

});
